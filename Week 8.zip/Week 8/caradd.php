<?php
	$Year = ($_COOKIE['year']);
	$Description = ($_COOKIE['desc']);
	$Cost = ($_COOKIE['cost']);
	$Down = ($_COOKIE['down']);
	$Interest = ($_COOKIE['rate']);
	$YearsFinanced = ($_COOKIE['yearsFin']);

	echo <<<_END
  <html>
  <head>
    <link href = "auto.css" rel = "stylesheet" type = "text/css" />
    <title>Bailey's Auto Shop</title>
  </head>

  <body>
  <img id="purch" src = "purchase.jpeg"/>
  <h1>Congratualtions on your Purchase!</h1>
  <h2>Here are the details </h2>

  <table>
    <tr><td>Year </td><td>$Year</td></tr>
    <tr><td>Description </td><td>$Description</td></tr>
    <tr><td>Cost </td><td>$Cost</td></tr>
    <tr><td>Interest Rate </td><td>$Interest</td></tr>
    <tr><td>Years Financed </td><td>$YearsFinanced</td></tr>
  </table>

  </body>

  </html>

  _END;

?>
