<?php 
  require_once 'login.php';

  try
  {
    $pdo = new PDO($attr, $user, $pass, $opts);
  }
  catch (PDOException $e)
  {
    throw new PDOException($e->getMessage(), (int)$e->getCode());
  }

  if (isset($_POST['delete']) && isset($_POST['VIN']))
  {
    $VIN   = get_post($pdo, 'VIN');
    $query  = "DELETE FROM cars WHERE VIN=$VIN";
    $result = $pdo->query($query);
  }

  if (isset($_POST['VIN'])   &&
      isset($_POST['Year'])    &&
      isset($_POST['Description']) &&
      isset($_POST['Cost'])     &&
      isset($_POST['Down'])     &&
      isset($_POST['YearsFinanced'])     &&
      isset($_POST['Interest']))
  {
    $VIN   = get_post($pdo, 'VIN');
    $Year    = get_post($pdo, 'Year');
    $Description = get_post($pdo, 'Description');
    $Cost     = get_post($pdo, 'Cost');
    $Down     = get_post($pdo, 'Down');
    $YearsFinanced     = get_post($pdo, 'YearsFinanced');
    $Interest     = get_post($pdo, 'Interest');


    
    $query    = "INSERT INTO cars VALUES" .
      "($VIN, $Year, $Description, $Cost, $Down, $YearsFinanced, $Interest)";
    $result = $pdo->query($query);

    setcookie('year',$Year,time()+3*24*60*60);
    setcookie('desc',$Description,time()+3*24*60*60);
    setcookie('cost',$Cost,time()+3*24*60*60);
    setcookie('down',$Down,time()+3*24*60*60);
    setcookie('rate',$Interest,time()+3*24*60*60);
    setcookie('yearsFin',$YearsFinanced,time()+3*24*60*60);
    echo "Car Added. <p><a href = 'caradd.php'>Click here to continue</a></p>";
  }

  

  echo <<<_END
  <html>
  <head>
    <link href = "auto.css" rel = "stylesheet" type = "text/css" />
    <title>Bailey's Auto Shop</title>
    <img src = "carImg.jpeg"/>

    <script>
    function validate(form)
    {
      fail = ""
      fail = validateVin(form.VIN.value)
      fail += validateYear(form.Year.value)
      fail += validateDesc(form.Description.value)
      fail += validateCost(form.Cost.value)
      fail += validateDown(form.Down.value)
      fail += validateFinance(form.YearsFinanced.value)
      fail += validateRate(form.Interest.value)
      if (fail =="") return true
      else {
        alert (fail)
        return false
      }
    }
    function validateVin(field){
      if (field == "") return "No VIN was entered.\\n"
      return ""
    }
    function validateYear(field){
      if (field == "") return "No year was entered.\\n"
      else if (isNaN(field)) return "Year must be a number.\\n"
      return ""
    }
    function validateDesc(field){
      if (field == "") return "No description was entered.\\n"
      return ""
    }
    function validateCost(field){
      if (field == "") return "No cost was entered.\\n"
      else if (isNaN(field)) return "Cost must be a number.\\n"
      else if (field > 1000000) return "Cost must be smaller than one million.\\n"
      return ""
    }
    function validateDown(field){
      if (field == "") return "No down payment was entered.\\n"
      else if (isNaN(field)) return "Down payment must be a number.\\n"
      return ""
    }
    function validateFinance(field){
      if (field == "") return "Years financed was not entered.\\n"
      else if (isNaN(field)) return "Years financed must be a number.\\n"
      else if (field > 100) return "Years financed must be less than 100.\\n"
      return ""
    }
    function validateRate(field){
      if (field == "") return "Interest rate was not entered.\\n"
      else if (isNaN(field)) return "Interest rate must be a number.\\n"
      return ""
    }
  </script>
  </head>

  <body>
  <h1>Bailey's Auto Shop</h1>

  <form action="automotive.php" method="post" onSubmit = "return validate(this)"><pre>
             VIN <input type="text" name="VIN">
            Year <input type="text" name="Year">
     Description <input type="text" name="Description">
            Cost <input type="text" name="Cost">
    Down Payment <input type="text" name="Down">
  Years Financed <input type="text" name="YearsFinanced">
   Interest Rate <input type="text" name="Interest"><br>
                 <input type="submit" value="ADD RECORD">
  </pre></form>

  </body>

  </html>

  _END;



$query = "SELECT * FROM cars";
$result = $pdo->query($query);

  

while ($row = $result->fetch())
{
	  $r0 = htmlspecialchars($row['VIN']);
    $r1 = htmlspecialchars($row['Year']);
    $r2 = htmlspecialchars($row['Description']);
    $r3 = htmlspecialchars($row['Cost']);
    $r4 = htmlspecialchars($row['Down']);
    $r5 = htmlspecialchars($row['YearsFinanced']);
    $r6 = htmlspecialchars($row['Interest']);
    
    echo <<<_END
  <pre>
  VIN: $r0
  Year: $r1
  Description: $r2
  Cost: $r3
  Down Payment: $r4
  Years Financed: $r5
  Interest Rate: $r6
  </pre>
  <form action='automotive.php' method='post'>
  <input type='hidden' name='delete' value='yes'>
  <input type='hidden' name='VIN' value='$r0'>
  <input type='submit' value='DELETE RECORD'></form>
_END;
}


function get_post($pdo, $var)
  {
    return $pdo->quote($_POST[$var]);
  }

?>
