<!DOCTYPE html> 
<html>
<head>
   <title>Bailey's Bed and Breakfast</title>
   <link href = "bed.css" rel = "stylesheet" type = "text/css" />
</head>

<body>
	<img src = "bed.jpeg" />
	<h1>Bailey's Bed and Breakfast</h1>



	<h2>Overview</h2>
	<p>At Bailey's Bed and Breakfast your comfort is our top priority. We offer four different room types to accomadate for everyone. We even offer an afternoon tea. Come visit us for a relaxing getaway! </p>

	<h2>Our Options</h2>
	<p><b>The Sage Room</b>(Sleeps 2) is $125.00 per night </p><br>

	<p><b>The Sun Room</b>(Sleeps 4) is $175.00 per night </p><br>

	<p><b>The Beachfront Room</b>(Sleeps 4) is $175.00 per night </p><br>

	<p><b>The Summer Room</b>(Sleeps 2) is $125.00 per night </p><br>

	<p>We also offer an afternoon tea which is $15.00 per night </p> <br>

	<h2>Book Your Stay</h2>

	<form action = "BedBreakfast.php" method = "post">
		<fieldset>
			<legend>Room Type</legend>

			<label>Select One:</label>
			<select name = "stay">
				<option value = "">Select</option>
				<option value = "Sage">The Sage Room</option>
				<option value = "Sun">The Sun Room</option>
				<option value = "Beach">The Beachfront Room</option>
				<option value = "Summer">The Summer Room</option>
			</select>
		</fieldset>
		<br>

		<fieldset>
			<legend>Number of Nights</legend>

			<label>How many nights are you staying?</label>
			<input type = "text" name = "number" required />

		</fieldset>
		<br>

		<fieldset>
			<legend>Afternoon Tea</legend>

			<label>How many nights would you like any tea?</label>
			<input type = "text" name = "afternoon" required /> 

		</fieldset>
		<br>

		<input type = "submit" value = "Place Order" />
      	

	</form>

	<h2>Total</h2>

	<table>
<?php

$room = $nights = $tea = "";

if(isset($_POST['stay'])) $room = $_POST['stay'];

if (isset($_POST['number'])) $nights = sanitize($_POST['number']);

if (isset($_POST['afternoon'])) $tea = sanitize($_POST['afternoon']);

if($_POST)
{
if($room) {

    if($room == "Sage")
        $roomnum = 1;
    else if($room == "Sun")
        $roomnum = 2;
    else if($room == "Beach")
        $roomnum = 3;
    else
        $roomnum = 4;
}

    switch($roomnum) {
        case 1:
            $description = "The Sage Room";
            $price = 125;
            break;
        case 2:
            $description = "The Sun Room";
            $price = 175;
            break;
        case 3:
            $description = "The Beachfront Room";
            $price = 175;
            break;
        case 4:
            $description = "The Summer Room";
            $price = 125;
            break;
    }

    $teaPrice = 15 * $nights;

    $totalprice = number_format(($price * $nights) + $teaPrice, 2);

    echo <<<_END
   <tr><td>Description:</td> <td>$description</td></tr>
   <tr><td>Nights:</td> <td>$nights</td></tr>
   <tr><td>Tea: $</td> <td>$teaPrice</td></tr>
   <tr><td>Total Price: $</td> <td>$totalprice</td></tr>
_END;
   }

    function sanitize($var) {
        $var = stripslashes($var);
        $var = htmlentities($var);
        $var = strip_tags($var);
        return $var;
    }

?>

	</table>


	</body>
	</html>
