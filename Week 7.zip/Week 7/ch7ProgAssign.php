<html>
<!-- Written by Bailey Vickery
	-->


<head>
	<h1>Office Max</h1>
	<img src = "officeImg.png" alt= "" />
	<br>

	<link href = "office.css" rel = "stylesheet" />


</head>

<body style="color:darkblue">

	<?php

	echo "Welcome to Office Max, where all your office needs are met. Down below is our current stock. <br>";

	echo "Today's date is " . date("m/d/Y") . "<br>";


	
	$myfile = fopen("Products.txt", 'r') or die("File does not exist");

	$products = array();
	echo "<pre>";
	printf("Product Name      Price      Quantity      Extended Price<br>");


	while(!feof($myfile)){
		$products = explode(',', fgets($myfile));
		printf("%-18s", $products[0]);
		printf("%-12.2f", $products[1]);
		printf("%-10.2f", $products[2]);
		$products[3] = $products[1] * $products[2];
		printf("%10.2f", $products[3]);
		echo "<br>";
	}


	?>


</body>

</html>