<?php 
/*
ExpenseTracker.php
Created 4/18/24 by Bailey Vickery
This program uses php, html, css, and js to track a users spending. 
*/
/*Datebase set up */
  require_once 'expenseLogin.php';

  try
  {
    $pdo = new PDO($attr, $user, $pass, $opts);
  }
  catch (PDOException $e)
  {
    throw new PDOException($e->getMessage(), (int)$e->getCode());
  }
     
/*Insert input to datebase and set cookies */
  if (isset($_POST['Amount'])   &&
      isset($_POST['Item'])    &&
      isset($_POST['Month']) &&
      isset($_POST['Payee']))
  {
    $Amount   = get_post($pdo, 'Amount');
    $Item    = get_post($pdo, 'Item');
    $Month = get_post($pdo, 'Month');
    $Payee     = get_post($pdo, 'Payee');
   
    
    $query    = "INSERT INTO expenses VALUES" .
      "($Amount, $Item, $Month, $Payee)";
    $result = $pdo->query($query);

    setcookie('amount', $Amount,time()+3*24*60*60);
    setcookie('item', $Item,time()+3*24*60*60);
    setcookie('month', $Month,time()+3*24*60*60);
    setcookie('payee', $Payee,time()+3*24*60*60);
    echo "Expense Added. <p><a href = 'expenseAdd.php'>Click here to view</a></p>";
  }
/*Set what month they want the overview for and their budget */
  if (isset($_POST['MonthOver'])   &&
      isset($_POST['Budget']))
  {
    $MonthOver   = get_post($pdo, 'MonthOver');
    $Budget    = get_post($pdo, 'Budget');
}


/*
Html code with functions to validate input and form 
*/
  echo <<<_END
  <html>
  <head>
    <title>Expense Tracker</title>
    <link href = "base.css" rel = "stylesheet">
    <script>
    	function validate(form){
    		fail = ""
    		fail = validateAmount(form.Amount.value)
    		fail += validateItem(form.Item.value)
    		fail += validatePayee(form.Payee.value)
    		if (fail =="") return true
    		else {
    			alert (fail)
    			return false
    		}
    	}
    	function validateAmount(field){
    		if (field == "") return "No amount was entered.\\n"
    		else if (isNaN(field)) return "Amount must be a number.\\n"
    		else if (field > 100000 || field < 1) return "Amount should be between $100000 and $1.\\n" 
    		return ""
    	}
    	function validateItem(field){
    		if (field == "") return "No item was entered.\\n"
    		return ""
    	}
    	function validatePayee(field){
    		if (field == "") return "No payee was entered.\\n"
    		return ""
    	}


    </script>
  </head>

  <body>
  <h1>Expense Tracker</h1>
  <img src = "dollar.jpeg">

  <p>Hello! Welcome to your personal expense tracker. </p>
  <p>We know saving money can be hard but this app is all you need to stick to a budget!</p>
  <p>This app allows you to track your expenses and then create a monthly overview. We track your expenses to help you stick to your budget. Once you've added your expenses you can create a monthly overview for whichever month you'd like. 

  <h3>Please enter your expenses below</h3>
  <form action="ExpenseTracker.php" method="post" onSubmit = "return validate(this)"><pre>
     Amount    <input type="text" name="Amount"><br>
     Item      <input type="text" name="Item"><br>
     Month     <select name = "Month">
     	            <option value = "January">January</option>
     				<option value = "February">February</option>
     				<option value = "March">March</option>
     				<option value = "April">April</option>
     				<option value = "May">May</option>
     				<option value = "June">June</option>
     				<option value = "July">July</option>
     				<option value = "August">August</option>
     				<option value = "September">September</option>
     				<option value = "October">October</option>
     				<option value = "November">November</option>
     				<option value = "December">December</option></select><br>
     Payee     <input type="text" name="Payee"><br>
                <input type="submit" value="ADD EXPENSE">
  </pre></form>

  <h3>Monthly Overview</h3>
  <form action = "ExpenseTracker.php" method = "post"><pre>
     Month            <select name = "MonthOver">
     	            <option value = "January">January</option>
     				<option value = "February">February</option>
     				<option value = "March">March</option>
     				<option value = "April">April</option>
     				<option value = "May">May</option>
     				<option value = "June">June</option>
     				<option value = "July">July</option>
     				<option value = "August">August</option>
     				<option value = "September">September</option>
     				<option value = "October">October</option>
     				<option value = "November">November</option>
     				<option value = "December">December</option></select><br>
     Monthly Budget   <input type = "text" name = "Budget"><br>
     	<input type="submit" value="CREATE OVERVIEW">
     </pre>
    </form>

  </body>

  </html>

  _END;

/*Code to implement monthlyOverview Function */
  if (isset($_POST['MonthOver']) && isset($_POST['Budget'])) {
    monthlyOverView($pdo, $_POST['MonthOver'], $_POST['Budget']);
}
/*function to create overview */
function monthlyOverView($pdo, $MonthOver, $Budget){
	$query = "SELECT * FROM expenses WHERE month = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$MonthOver]);
    $totalSpent = 0;

    //Output of table headers
  echo <<<_END
  <table border="3" cellpadding="2">
  <h1>Monthly Overview</h1>
  <tr>
  <th>Amount</th>
  <th>Item</th>
  <th>Month</th>
  <th>Payee</th>
  </tr>
  _END;

	while ($row = $stmt->fetch())
{
    echo "<tr><td>" . htmlspecialchars($row['amount']) . "</td>";
    echo "<td>" . htmlspecialchars($row['item']) . "</td>";
    echo "<td>" . htmlspecialchars($row['month']) . "</td>";
    echo "<td>" . htmlspecialchars($row['payee']) . "</td>";
    echo "</tr>";

}
if ($totalSpent > $Budget){
    	echo "<p>You went over your budget this month.</p>";
    }
    else {
    	echo "<p>Woohoo! You stuck to your $$Budget budget!</p>";
    }
}


function get_post($pdo, $var)
  {
    return $pdo->quote($_POST[$var]);
  }

?>
