<?php
/*Created by Bailey Vickery 4/19/24
Page to display cookie information */
$Amount = ($_COOKIE['amount']);
$Item = ($_COOKIE['item']);
$Month = ($_COOKIE['month']);
$Payee = ($_COOKIE['payee']);

echo <<<_END
<html>
<head>
	<link href = "base.css" rel = "stylesheet">
	<title>Expense Tracker</title>
</head>

<body>
<img src = "dollar.jpeg">
<h1>Expense Successfully Added!</h1>
<h2>Here are the details</h2>

<table>
<tr><td>Amount: </td><td>$Amount</td></tr>
<tr><td>Item: </td><td>$Item</td></tr>
<tr><td>Month: </td><td>$Month</td></tr>
<tr><td>Payee: </td><td>$Payee</td></tr>
</table>

<p><a href = "ExpenseTracker.php">Click here to return to main page</a></p>

</body>
</html>
_END;
?>