-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 29, 2024 at 03:52 PM
-- Server version: 8.0.31
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `expenseTracker`
--

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `amount` int NOT NULL,
  `item` text COLLATE utf8mb4_general_ci NOT NULL,
  `month` set('January','February','March','April','May','June','July','August','September','October','November','December') COLLATE utf8mb4_general_ci NOT NULL,
  `payee` text COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`amount`, `item`, `month`, `payee`) VALUES
(10, 'Gas', 'April', 'Mobile'),
(10, 'Gas', 'April', 'Mobile'),
(40, 'Food', 'May', 'Applebees'),
(40, 'Food', 'May', 'Applebees'),
(20, 'Snack', 'February', 'Gas Station'),
(100, 'Jeans', 'April', 'Kohls'),
(100, 'Jeans', 'April', 'Kohls'),
(10, 'Gas', 'January', 'Mobile'),
(10, 'Shirt', 'April', 'Walmart'),
(10, 'Gas', 'January', 'Mobile'),
(40, 'Bills', 'November', 'Consumers'),
(300, 'Tent', 'June', 'Walmart'),
(100, 'Vet Bills', 'June', 'Brooklyn Vet'),
(40, 'Concert', 'January', 'Detroit'),
(10, 'Milk', 'January', 'Mejier'),
(300, 'Grocery', 'February', 'Mejier'),
(300, 'car problems', 'April', 'Auto work');

-- --------------------------------------------------------

--
-- Table structure for table `monthlyBudget`
--

CREATE TABLE `monthlyBudget` (
  `January` int NOT NULL,
  `February` int NOT NULL,
  `March` int NOT NULL,
  `April` int NOT NULL,
  `May` int NOT NULL,
  `June` int NOT NULL,
  `July` int NOT NULL,
  `August` int NOT NULL,
  `September` int NOT NULL,
  `October` int NOT NULL,
  `November` int NOT NULL,
  `December` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `monthlyBudget`
--

INSERT INTO `monthlyBudget` (`January`, `February`, `March`, `April`, `May`, `June`, `July`, `August`, `September`, `October`, `November`, `December`) VALUES
(100, 120, 120, 100, 120, 120, 300, 300, 20, 100, 100, 230);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
